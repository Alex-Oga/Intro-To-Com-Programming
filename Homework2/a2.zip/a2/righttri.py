# Assignment 2, Task 7
# Name: Alexander Ogay
# Collaborators:
# Time Spent: 0:20 hrs
# x: float = 4.0
# y: float = 5.0
# z: float = 3.0
right_triangle: bool = (x**2+y**2==z**2) or (x**2+z**2==y**2) or (y**2+z**2==x**2)
print(right_triangle)