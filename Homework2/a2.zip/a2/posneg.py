# Assignment 2, Task 2
# Name: Alexander Ogay
# Collaborators:
# Time Spent: 0:20 hrs
# a: int = -1
# b: int = -1
# negative: bool = False
pos_neg = a>0 and b<0 or a<0 and b>0 or negative == True and a<0 and b<0
# a bigger than 0 and b smaller than 0 = True
# or
# a smaller than 0 and b bigger than 0 = True
# or
# negative == True and a and b are smaller than 0 = True
print(pos_neg)