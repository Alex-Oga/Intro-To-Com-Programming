# Assignment 3, Task 3
# Name: Alexander Ogay
# Collaborators:
# Time Spent: 4:00 hrs
def kthDigit(x: int, b: int, k: int) -> int:
