# Assignment 6, Task 3
# Name: Alexander Ogay
# Collaborators:
# Time Spent: 4:00 hrs
from typing import Dict
from typing import List
