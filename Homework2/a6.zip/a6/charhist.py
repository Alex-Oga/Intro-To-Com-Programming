# Assignment 6, Task 1
# Name: Alexander Ogay
# Collaborators:
# Time Spent: 4:00 hrs